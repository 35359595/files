# IB Link Validation & Telemetry Collector

## Overview

This script connects to IB and UFM 3.0 devices deployed in XDR GB300 clusters, executes iblinkinfo commands, collects link-level telemetry data, consolidates it into a timestamped report, and uploads the result to AWS S3 (or S3-compatible storage).

It is designed to automate large-scale fabric validation and monitoring by:

- Establishing parallel SSH connections across multiple devices
- Supporting IB switches and UFM 3.0 devices
- Targeting XDR GB300 cluster deployments
- Executing device-specific iblinkinfo commands
- Collecting and validating telemetry output
- Consolidating results into a timestamped report
- Uploading the consolidated report to S3 and cleaning up the local copy on success
- Categorizing and logging failures for operational visibility
- Persisting all failures to a rotating log file (scheduler-friendly)

Supported scope: XDR GB300 clusters only, using IB switches and UFM 3.0 devices.

---

## Features

- Supports UFM 3.0 and IB devices (XDR GB300 clusters)
- Parallel execution using multiprocessing
- Timestamped output files
- Automatic S3 upload of the consolidated report
- Safe cleanup - local file deleted only after a confirmed successful upload
- Structured failure reporting
- Append-based failure logging across runs
- Rotating log file for all failures (logs/telemetry_automation.log)
- Start/end banners with total execution time
- Clean separation of RAW and FINAL outputs
- Suppressed paramiko noise for clean console output

---

## Directory Structure

    project/
    |
    |-- collect_ib_telemetry.py        # Main script
    |-- s3_utils.py                    # S3 client + upload helper module
    |-- config.json                    # Credentials + S3 configuration
    |-- servers.csv                    # Input device list
    |-- requirements.txt               # Python dependencies
    |-- failures.txt                   # Append-based failure log
    |
    |-- logs/                          # Auto-created
    |   |-- telemetry_automation.log   # Rotating failure log (active, newest)
    |   |-- telemetry_automation.log.1 # Rotated backup (newer)
    |   |-- telemetry_automation.log.5 # Rotated backup (oldest)
    |   |-- cron_stdout.log            # (optional) cron capture
    |
    |-- output/                        # Auto-created
        |-- raw/                       # Temporary per-device output (cleared each run)
        |-- final/                     # Consolidated output (deleted after S3 upload)

### File Ownership

| Category | Files |
|----------|-------|
| You provide | collect_ib_telemetry.py, s3_utils.py, config.json, servers.csv, requirements.txt |
| Auto-created | logs/, output/raw/, output/final/, failures.txt |
| Temporary | output/raw/*.txt (wiped at the start of every run) |
| Uploaded then deleted | output/final/IBLINKINFO_*.txt (removed after confirmed S3 upload) |
| Persistent records | logs/telemetry_automation.log, failures.txt |

---

## Supported Devices and Clusters

| Item | Supported |
|------|-----------|
| Cluster type | XDR GB300 only |
| Device types | IB switches, UFM 3.0 / 3.5|
| Link type | XDR |

Note: NDR clusters are not supported.

---

## Configuration (config.json)

    {
      "process_count": 25,
      "credentials": {
        "UFM3": [
          { "username": "ufm3-username", "password": "ufm3-pwd" }
        ],
        "IB": [
          { "username": "ib-username-1", "password": "ib-pwd-1" },
          { "username": "ib-username-2", "password": "ib-pwd-2" }
        ]
      },
      "S3_cred": {
        "endpoint_url": "https://s3.<region>.amazonaws.com",
        "bucket_name": "your-bucket-name",
        "upload_folder_path": "telemetry/iblink"
      }
    }

### Configuration Fields

| Field | Description |
|-------|-------------|
| process_count | Maximum number of parallel workers |
| credentials | Device login credentials (per device type) |
| S3_cred.endpoint_url | S3 endpoint. Use the regional AWS URL or a custom endpoint (MinIO/LocalStack). Must be a valid, non-empty URL. |
| S3_cred.bucket_name | Destination S3 bucket name |
| S3_cred.upload_folder_path | Object key / path prefix used for the uploaded file |

Authentication: AWS credentials are resolved by boto3 via environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN), the AWS credentials file, or an IAM role / instance profile. Prefer IAM roles over hardcoding keys.

---

## Input File (servers.csv)

| Column Name | Description |
|-------------|-------------|
| ServerAddress | Device IP or hostname |
| DeviceConfig | Device type (3.0 for UFM, IB for InfiniBand) |
| ClusterName | Cluster name |
| LinkType | Link type (XDR) |

Ensure the CSV headers match the column names exactly. The script validates columns up front and fails fast with a clear error if any are missing.

Example:

    ServerAddress,DeviceConfig,ClusterName,LinkType
    10.1.1.5,IB,clusterA,XDR
    10.1.1.6,ufm-3.0,clusterB,XDR
    10.1.1.7,ufm-3.5,clusterC,XDR

---

## Installation

    pip install -r requirements.txt

requirements.txt:

    pandas==3.0.2
    paramiko==4.0.0
    cryptography
    boto3
    botocore

---

## Execution

    python3 collect_ib_telemetry.py servers.csv

### Scheduling (cron)

    0 6 * * * cd /mnt/suvankar/lv_new && /usr/bin/python3 collect_ib_telemetry.py servers.csv >> logs/cron_stdout.log 2>&1

### Sample Console Output (successful run)

    Program is started at 06-18-2026 20:50:02 PDT
    [STAGE 1] Collecting telemetry data from devices...
    [STAGE 2] File generated: IBLINKINFO_20260619_084647.txt
    Processed: 3 | Success: 3 | Failed: 0
    [STAGE 3] Uploading file to S3...
    [SUCCESS] S3 upload completed -> your-bucket-name/telemetry/iblink
    Program is ended at   06-18-2026 20:55:58 PDT
    Total execution time  : 0m 47s

---

## Output Format

| Type | Location | Description |
|------|----------|-------------|
| Final Output | output/final/ | Consolidated telemetry output (timestamped). Deleted locally after a successful S3 upload; retained if upload fails. |
| Raw Output | output/raw/ | Temporary per-device output (cleared at every run) |
| Failure Summary | failures.txt | Append-based human-readable failure tracking |
| Run Log | logs/telemetry_automation.log | Rotating log of all failures (5 MB x 5 backups, about 30 MB cap) |

### File Naming Conventions

| File | Pattern | Example |
|------|---------|---------|
| Final output | IBLINKINFO_<YYYYMMDD>_<HHMMSS>.txt (UTC) | IBLINKINFO_20260619_084647.txt |
| Raw per-device | <cluster>_<server>_<epoch>.txt | clusterA_10.1.1.5_1750300000.txt |
| Run log | telemetry_automation.log (+ .1 to .5) | rotated at 5 MB |

---

## Logging

The script uses a rotating log file so it is safe for long-running scheduled jobs. A single logger call writes to both the console and the log file.

| Aspect | Detail |
|--------|--------|
| Location | logs/telemetry_automation.log |
| Handler | RotatingFileHandler + StreamHandler (console) |
| Rotation | Rotates at 5 MB (maxBytes=5_000_000) |
| Backups | Keeps 5 backups (backupCount=5): .log.1 (newest) to .log.5 (oldest) |
| Disk cap | About 30 MB total, guaranteed - never grows unbounded |
| Format | mm-dd-YYYY HH:MM:SS [LEVEL] message |
| Scope | Failures only - normal flow uses console (print) |

### How Rotation Works

1. Logs are written to the active telemetry_automation.log.
2. When it reaches 5 MB, it is renamed to .log.1 and a fresh active file is created.
3. On each subsequent rotation, files shift down (.1 to .2, .2 to .3, and so on).
4. Once 5 backups exist, the oldest (.log.5) is deleted.

### Mandatory Failure Points Captured in the Log

| Log Tag | Trigger |
|---------|---------|
| [DEVICE FAILURE] | A device failed during telemetry collection |
| [ALERT] | Empty CSV / no successful telemetry / empty payload |
| [FAILURE] | S3 client creation failure or upload failure |
| [FATAL] | Unhandled exception (full traceback recorded) |

On a fully successful run, nothing is written to the log file - only failures are persisted.

### Sample Log File Content (failure run)

    06-18-2026 20:50:48 [ERROR] [DEVICE FAILURE] 10.1.1.5 | clusterA | Device not Responding
    06-18-2026 20:50:48 [ERROR] [FAILURE] S3 upload failed: Access denied. Check IAM permissions for s3:PutObject.

---

## Failure Categories

### Device Failure Types

| Failure Message | Description |
|-----------------|-------------|
| Configuration not recognized | Device type does not match supported values (IB, 3.0) |
| Provided credentials not working | All configured credentials failed authentication |
| Device Unaccessible | Device is unreachable (network/DNS/refused connection) |
| Device not Responding | SSH session established but command timed out |
| Device Authorizable but data error | Login successful but command output is invalid or insufficient |
| Unknown failure | Unexpected runtime error occurred during execution |

### S3 / Run-Level Failures

| Failure Message | Description |
|-----------------|-------------|
| Could not create S3 client | Invalid/empty endpoint_url or credential/region resolution failed |
| S3 upload failed [AccessDenied] | Missing s3:PutObject IAM permission |
| S3 upload failed [NoSuchBucket] | Bucket does not exist or is not accessible |
| S3 upload failed [InvalidAccessKeyId] | Invalid AWS access key ID |
| Final output file has no data | No telemetry collected; upload skipped |

---

## Behavior

- Failures are logged in append mode in failures.txt
- All failures are mandatorily persisted to logs/telemetry_automation.log
- Each execution is recorded with Automation Start Time, device failure entries, and Automation End Time and duration
- Local report is deleted only after a confirmed successful S3 upload (no data loss on failure)
- No historical data is lost across runs

---

## Module Reference (s3_utils.py)

| Function | Returns | Description |
|----------|---------|-------------|
| create_s3_client(...) | boto3 client or None | Creates an S3 client; supports region, explicit keys, session token, and custom endpoint |
| upload_file_to_s3(...) | dict | Uploads a file; always returns a status dict (success or error with reason) |

The module attaches a NullHandler and does not configure logging itself - it inherits the main script's rotating-log and console handlers, so all S3 errors are automatically captured in logs/telemetry_automation.log.

---

## Author

IB Telemetry Automation Script for Link Validation, Monitoring and S3 Archival

Maintained by:
- Mahipal Reddy (v-mahipal@microsoft.com)
- Suvankar Bera (v-suvabera@microsoft.com)
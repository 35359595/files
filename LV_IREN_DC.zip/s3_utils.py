"""
s3_utils.py
Utility functions for connecting to AWS S3, uploading files, and deleting files.

Dependencies:
    pip install boto3 botocore

Authentication options supported by boto3:
    1. Environment variables:
       AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN, AWS_DEFAULT_REGION
    2. AWS credentials/config files:
       ~/.aws/credentials and ~/.aws/config
    3. IAM role / instance profile / ECS task role / EKS IRSA
    4. Explicit credentials passed to create_s3_client(...)

Return contract:
    - create_s3_client() returns a boto3 S3 client on success, or None on failure.
    - upload_file_to_s3() ALWAYS returns a dict:
        {"status": "success", ...} on success
        {"status": "error", "reason": "..."} on any failure
      (No exceptions propagate out for expected failure modes.)
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import boto3
from botocore.client import BaseClient
from botocore.exceptions import (
    BotoCoreError,
    ClientError,
    EndpointConnectionError,
    NoCredentialsError,
    NoRegionError,
    PartialCredentialsError,
    ParamValidationError,
)

# ------------------------------------------------------------------
# Library-safe logging:
# Do NOT call logging.basicConfig() in a reusable module — that's the
# application's job. Attach a NullHandler so this module never emits
# unexpected output unless the host application configures logging.
# ------------------------------------------------------------------
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


# ============================================================
# Create S3 client
# ============================================================
def create_s3_client(
    region_name: Optional[str] = None,
    aws_access_key_id: Optional[str] = None,
    aws_secret_access_key: Optional[str] = None,
    aws_session_token: Optional[str] = None,
    endpoint_url: Optional[str] = None,
) -> Optional[BaseClient]:
    """
    Create and return an S3 client.

    Recommended production usage:
        - Prefer IAM roles or AWS profiles over hardcoding credentials.
        - Do not commit credentials to source control.

    Args:
        region_name: AWS region, e.g. "ap-south-1".
        aws_access_key_id: Optional explicit access key.
        aws_secret_access_key: Optional explicit secret key.
        aws_session_token: Optional session token (required for temporary
            STS credentials, e.g. assumed IAM roles).
        endpoint_url: Optional custom endpoint, useful for LocalStack/MinIO.

    Returns:
        A boto3 S3 client on success, or None if client creation fails.
    """
    try:
        return boto3.client(
            "s3",
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
            endpoint_url=endpoint_url,
        )

    except NoCredentialsError as exc:
        logger.error("AWS credentials were not found: %s", exc)
    except PartialCredentialsError as exc:
        logger.error("Incomplete AWS credentials were provided: %s", exc)
    except NoRegionError as exc:
        logger.error("AWS region was not configured or provided: %s", exc)
    except (BotoCoreError, Exception) as exc:
        logger.error("Failed to create S3 client: %s", exc)

    return None


# ============================================================
# Upload file to S3
# ============================================================
def upload_file_to_s3(
    s3_client: BaseClient,
    file_path: str | os.PathLike[str],
    bucket_name: str,
    object_key: Optional[str] = None,
    extra_args: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Upload a local file to an S3 bucket.

    Args:
        s3_client: boto3 S3 client returned by create_s3_client().
        file_path: Local path of the file to upload.
        bucket_name: Destination S3 bucket name.
        object_key: Destination object key. If omitted, local filename is used.
        extra_args: Optional boto3 ExtraArgs, e.g.
            {"ContentType": "text/csv", "ServerSideEncryption": "AES256"}

    Returns:
        On success:
            {"status": "success", "bucket": ..., "key": ..., "file_path": ...}
        On failure:
            {"status": "error", "reason": "<human-readable message>"}
    """
    # ---------------- Input validation (each guard STOPS execution) ----------------
    if s3_client is None:
        msg = "s3_client cannot be None."
        logger.error(msg)
        return {"status": "error", "reason": msg}

    if not bucket_name or not bucket_name.strip():
        msg = "bucket_name cannot be empty."
        logger.error(msg)
        return {"status": "error", "reason": msg}

    path = Path(file_path)

    if not path.exists():
        msg = f"File does not exist: {path}"
        logger.error(msg)
        return {"status": "error", "reason": msg}

    if not path.is_file():
        msg = f"Path is not a file: {path}"
        logger.error(msg)
        return {"status": "error", "reason": msg}

    if not os.access(path, os.R_OK):
        msg = f"File is not readable: {path}"
        logger.error(msg)
        return {"status": "error", "reason": msg}

    final_object_key = object_key or path.name
    if not final_object_key or final_object_key.strip() in {"", "/"}:
        msg = "object_key cannot be empty."
        logger.error(msg)
        return {"status": "error", "reason": msg}

    # ---------------- Upload ----------------
    try:
        s3_client.upload_file(
            Filename=str(path),
            Bucket=bucket_name,
            Key=final_object_key,
            ExtraArgs=extra_args or {},
        )

        return {
            "status": "success",
            "bucket": bucket_name,
            "key": final_object_key,
            "file_path": str(path),
        }

    except FileNotFoundError as exc:
        # Race condition: file removed after validation but before upload.
        msg = f"File disappeared before upload: {path}"
        logger.error("%s (%s)", msg, exc)
        return {"status": "error", "reason": msg}

    except PermissionError as exc:
        msg = f"Permission denied while reading file: {path}"
        logger.error("%s (%s)", msg, exc)
        return {"status": "error", "reason": msg}

    except NoCredentialsError as exc:
        msg = "AWS credentials were not found."
        logger.error("%s (%s)", msg, exc)
        return {"status": "error", "reason": msg}

    except PartialCredentialsError as exc:
        msg = "Incomplete AWS credentials were provided."
        logger.error("%s (%s)", msg, exc)
        return {"status": "error", "reason": msg}

    except EndpointConnectionError as exc:
        msg = "Could not connect to the S3 endpoint."
        logger.error("%s (%s)", msg, exc)
        return {"status": "error", "reason": msg}

    except ParamValidationError as exc:
        msg = f"Invalid parameter passed to S3 upload: {exc}"
        logger.error(msg)
        return {"status": "error", "reason": msg}

    except ClientError as exc:
        error = exc.response.get("Error", {})
        code = error.get("Code", "Unknown")
        message = error.get("Message", str(exc))

        friendly_messages = {
            "AccessDenied": "Access denied. Check IAM permissions for s3:PutObject.",
            "NoSuchBucket": "Bucket does not exist or is not accessible.",
            "InvalidAccessKeyId": "Invalid AWS access key ID.",
            "SignatureDoesNotMatch": "AWS secret key/signature is invalid.",
            "EntityTooLarge": "Object is too large for this upload method/configuration.",
            "SlowDown": "S3 throttled the request. Retry with backoff.",
        }
        reason = f"S3 upload failed [{code}]: {friendly_messages.get(code, message)}"
        logger.error(reason)
        return {"status": "error", "reason": reason, "code": code}

    except BotoCoreError as exc:
        msg = f"Low-level boto3/botocore error during upload: {exc}"
        logger.error(msg)
        return {"status": "error", "reason": msg}

    except Exception as exc:
        logger.exception("Unexpected error during S3 upload")
        return {"status": "error", "reason": f"Unexpected error during S3 upload: {exc}"}